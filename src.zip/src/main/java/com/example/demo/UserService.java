package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;

public class UserService {
	@Autowired
	public IUserDAO userDAO;//dependency,  tight coupling
	public void save1() {
		userDAO.save();
	}
}
