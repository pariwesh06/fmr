package com.demo.jms.template;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.springframework.stereotype.Component;

@Component
public class Consumer implements MessageListener {
  public void onMessage(Message message) {
    try {
      TextMessage textMessage = (TextMessage) message;
      System.out.println("received="+textMessage.getText());
      if(message.getBooleanProperty("prop1")==true){
    	  message.acknowledge();
      }
//      simpleService.processText(textMessage.getText());
    } catch (JMSException ex) {
      ex.printStackTrace();
    }
  }
}
