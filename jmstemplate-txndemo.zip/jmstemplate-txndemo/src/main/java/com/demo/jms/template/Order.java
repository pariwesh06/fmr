package com.demo.jms.template;

public class Order {

}
