package com.demo.jms.template;

import javax.jms.ConnectionFactory;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.config.SimpleJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.support.converter.MessageConverter;

@Configuration
public class Config {
	@Bean
	protected JmsTemplate jmsTemplate(ConnectionFactory connectionFactory) {
		return new JmsTemplate(connectionFactory);
	}
	 @Bean
	public ConnectionFactory connectionFactory() {
		ActiveMQConnectionFactory connectionFactory=new  ActiveMQConnectionFactory("tcp://localhost:61616");
		return connectionFactory;
	}
	 @Bean
	public DefaultMessageListenerContainer defaultMessageListenerContainer() {
		DefaultMessageListenerContainer container = new DefaultMessageListenerContainer();
		container.setDestination(new ActiveMQQueue("Queue"));
		container.setMessageListener(new Consumer());
		container.setConnectionFactory(connectionFactory());
		return container;
		
	}
	/*
	  public DefaultJmsListenerContainerFactory jmsListenerContainerFactory(
	      ConnectionFactory connectionFactory, MessageConverter messageConverter) {
	    DefaultJmsListenerContainerFactory factory =
	        new DefaultJmsListenerContainerFactory();
	    factory.setConnectionFactory(connectionFactory);
	    factory.setMessageConverter(messageConverter);
	    return factory;
	  }*/
	  /* @Bean // Strictly speaking this bean is not necessary as boot creates a default
	    JmsListenerContainerFactory connectionFactory(ConnectionFactory connectionFactory) {
	        SimpleJmsListenerContainerFactory factory = new SimpleJmsListenerContainerFactory();
	        factory.setConnectionFactory(connectionFactory);
	        return factory;
	    }
	   */
	 

}
