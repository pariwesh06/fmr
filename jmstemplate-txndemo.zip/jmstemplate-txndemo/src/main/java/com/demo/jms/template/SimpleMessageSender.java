package com.demo.jms.template;

import java.util.Enumeration;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.QueueBrowser;
import javax.jms.Session;

import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.BrowserCallback;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

@Component
public class SimpleMessageSender {
	private static final String SIMPLE_MESSAGE = "simple message";
	private JmsTemplate jmsTemplate;
	private String QUEUE="Queue";

	@Autowired
	public SimpleMessageSender(JmsTemplate jmsTemplate) {
		super();
		this.jmsTemplate = jmsTemplate;
	}

	public void send() {
		System.out.println("Sending message: "+ SIMPLE_MESSAGE);
		//check point-1
		jmsTemplate.send(QUEUE, new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				return session.createTextMessage(SIMPLE_MESSAGE);
			}
		});
		//check point-2
		/*jmsTemplate.setDefaultDestination(new ActiveMQQueue("defaultQ"));
		jmsTemplate.send(new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				return session.createTextMessage("message to default QUEUE");
			}
		});*/
		
		/* Message message= jmsTemplate.sendAndReceive(QUEUE,new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				return session.createTextMessage("message to default QUEUE");
			}
		});*/
		
		
		//read messages from a queue
		/*jmsTemplate.browse(QUEUE, new BrowserCallback<String>() {
			public String doInJms(Session session, QueueBrowser browser)
					throws JMSException {
				Enumeration itr = browser.getEnumeration();
				while (itr.hasMoreElements()) {
					ActiveMQTextMessage str = (ActiveMQTextMessage) itr.nextElement();
					System.out.println(str.getText());
				}
				return null;
			}
		});*/
		
		/*jmsTemplate.convertAndSend(QUEUE, "convert and send message");
		
		jmsTemplate.send(QUEUE, new MessageCreator() {
			public Message createMessage(Session session) throws JMSException {
				System.out.println(session.getAcknowledgeMode());
				Message message = session.createTextMessage();
				message.setBooleanProperty("prop1", true);
				return message;
			}
		});*/
	}
}