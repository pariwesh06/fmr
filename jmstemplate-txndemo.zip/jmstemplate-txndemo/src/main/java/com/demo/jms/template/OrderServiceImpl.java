package com.demo.jms.template;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Component;
//@Component
public class OrderServiceImpl {
	@JmsListener(destination="Queue")
	@SendTo("queue.confirmation")
	public OrderConfirmation order(Order o) {
		return new OrderConfirmation();
	}
}	
