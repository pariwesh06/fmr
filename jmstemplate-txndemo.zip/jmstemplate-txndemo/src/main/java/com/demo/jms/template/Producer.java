package com.demo.jms.template;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class Producer {
	@Autowired
	JmsTemplate jmsTemplate;
	public void  sendMessage() {
		jmsTemplate.convertAndSend("q1", "message1");
	}
}
