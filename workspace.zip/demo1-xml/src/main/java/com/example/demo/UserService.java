package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;

public class UserService {
//	@Autowired
	public IUserDAO userDAO;//dependency,  tight coupling
	private String url;
	public void setUrl(String url) {
		this.url = url;
	}
	/*public UserService(IUserDAO userDAO) {
		this.userDAO=userDAO;
	}
	
	public UserService(IUserDAO userDAO, int a) {
		this.userDAO=userDAO;
	}*/
	public void setUserDAO(IUserDAO userDAO) {
		this.userDAO = userDAO;
	}
	public void save1() {
		userDAO.save();
	}
}
