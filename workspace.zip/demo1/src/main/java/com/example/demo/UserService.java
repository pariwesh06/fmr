package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;

public class UserService {
//	@Autowired//field DI
	private IUserDAO userDAO;//dependency,  tight coupling
	
	public IUserDAO getUserDAO() {
		return userDAO;
	}
	//Constructor DI
	public UserService(IUserDAO userDAO) {
		this.userDAO=userDAO;
	}
	
	/*@Autowired //setter DI
	public void setUserDAO(IUserDAO userDAO) {
		this.userDAO = userDAO;
	}*/


	public void save1() {
		userDAO.save();
	}
}
