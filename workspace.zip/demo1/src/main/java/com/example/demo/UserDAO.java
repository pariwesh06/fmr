package com.example.demo;

public class UserDAO implements IUserDAO{
	public void save() {
		System.out.println("Called###");
	}
}
