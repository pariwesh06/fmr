package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class UserService {
//	@Autowired
	public IUserDAO userDAO;//dependency,  tight coupling
	public IUserDAO getUserDAO() {
		return userDAO;
	}
	
	public UserService(IUserDAO userDAO) {
		this.userDAO=userDAO;
	}
	/*@Autowired
	public void setUserDAO(IUserDAO userDAO) {
		this.userDAO = userDAO;
	}*/
	public void save1() {
		userDAO.save();
	}
}
