package com.example.demo;

import org.springframework.stereotype.Component;

//@Component
public class UserDAO implements IUserDAO{
	public void save() {
		System.out.println("Called###");
	}
}
